local concreteItem = data.raw["item"]["concrete"]
concreteItem.stack_size = 2000

local concreteRecipe = data.raw["recipe"]["concrete"]
concreteRecipe.ingredients = {
    {name="concrete", amount=100}
}

data:extend({concreteItem})
data:extend({concreteRecipe})