local refinedConcreteItem = data.raw["item"]["refined-concrete"]
refinedConcreteItem.stack_size = 2000

local refinedConcreteRecipe = data.raw["recipe"]["refined-concrete"]
refinedConcreteRecipe.ingredients = {
    {name="concrete", amount=100}
}

data:extend({refinedConcreteItem})
data:extend({refinedConcreteRecipe})